export class CompileInfo {
	status: string;
	filePath: string;
	message: string;
	detail: string;
}
