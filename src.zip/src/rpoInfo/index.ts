import { RpoInfoLoader } from "./rpoInfoLoader";

export { RpoInfoLoader as CreateRpoInfoLoader };
